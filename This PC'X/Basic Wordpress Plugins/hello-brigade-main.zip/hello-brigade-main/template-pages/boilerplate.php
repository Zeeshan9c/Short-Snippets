<?php
/**
 * Template Name: Boilerplate Template
 * 
 */

get_header();

    // code here...

get_footer();
