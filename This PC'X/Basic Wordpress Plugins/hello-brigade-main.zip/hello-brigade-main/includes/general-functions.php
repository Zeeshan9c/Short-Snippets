<?php

/**
 * General functions
 * 
 */

