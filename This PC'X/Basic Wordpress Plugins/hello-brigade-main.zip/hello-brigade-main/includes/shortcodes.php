<?php

/**
 * Contains all the shortcodes
 * 
 */

