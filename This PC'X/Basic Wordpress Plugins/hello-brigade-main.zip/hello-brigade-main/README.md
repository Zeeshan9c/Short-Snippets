# hello-brigade
A starter theme for Elementor

## Notes ##
* Put the JS/CSS libraries in the `assets/vendor/*` folder, only out own custom JS will go in the `assets/js/*` folder.