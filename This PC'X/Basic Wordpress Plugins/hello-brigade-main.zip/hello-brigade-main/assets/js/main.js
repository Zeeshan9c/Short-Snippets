(function ($) {
	'use strict';

    // --------------------------------------------------
	// Other Code here
	// --------------------------------------------------

    // code here ...
    
    // --------------------------------------------------
	// Popup open/close
	// --------------------------------------------------

    $('.popup-toggle').on('click', function (e) {
        e.preventDefault();
        let container = $(this).attr('data-popup') && 'undefined' !== typeof $(this).attr('data-popup') ? $(this).attr('data-popup') : $(this).parents('.popup-container');
        $( container + '.popup-container' ).toggleClass('is-visible');
    });

    // HTML markup is:

    /*
    <div class="popup-toggle" data-popup="#my-custom-popup">Button to open</div>

    <div id="my-custom-popup" class="popup-container">

        <div class="popup-overlay popup-toggle"></div>

        <div class="popup-toggle">close button</div>

        <div class="popup-wrapper">
            some content will go here...
        </div>

    </div>
    */


    // --------------------------------------------------
	// Cursor positioning for GForm elements
	// --------------------------------------------------
	$.fn.setCursorPosition = function(pos) {
		this.each(function(index, elem) {
			if (elem.setSelectionRange) {
				elem.setSelectionRange(pos, pos);
			} else if (elem.createTextRange) {
				var range = elem.createTextRange();
				range.collapse(true);
				range.moveEnd('character', pos);
				range.moveStart('character', pos);
				range.select();
			}
		});
		return this;
	};
	$(document).on('focus', '.input-target input', function() {
		var el = $(this);
		setTimeout(function() {
			if (el.val() == '(___) ___-____')
				el.setCursorPosition(1);
		}, 75);
	});


    // --------------------------------------------------
	// jQuery Match Height
	// --------------------------------------------------

	// all the elements where MatchHeight will be applied to
	const matchHeightElements = [
		'.class-name-here',
	];

	// apply matchHeight to a single element
	function doMatchHeight( _element ) {
		$( _element ).matchHeight({
			byRow: true,
			property: 'min-height',
		});
	}
	
	// apply match height to all the elements
	$(window).on('resize load', function() {
		matchHeightElements.forEach( doMatchHeight );
	});


})(jQuery);