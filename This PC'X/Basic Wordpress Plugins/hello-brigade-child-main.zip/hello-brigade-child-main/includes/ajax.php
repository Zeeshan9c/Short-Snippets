<?php

/**
 * AJAX functions
 * 
 */

